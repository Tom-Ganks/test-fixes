class Usuario {
  int? idUsuario;
  String nome;
  String telefone;
  String email;
  String endereco;
  int cargo;

  Usuario({
    this.idUsuario,
    required this.nome,
    required this.telefone,
    required this.email,
    required this.endereco,
    required this.cargo,
  });

  // Converter de um Map para o objeto Usuario
  factory Usuario.fromMap(Map<String, dynamic> map) {
    return Usuario(
      idUsuario: map['idUsuarios'],
      nome: map['Nome'],
      telefone: map['Telefone'],
      email: map['Email'],
      endereco: map['Endereco'],
      cargo: map['Cargo'],
    );
  }

  // Converter do objeto Usuario para um Map
  Map<String, dynamic> toMap() {
    return {
      'idUsuarios': idUsuario,
      'Nome': nome,
      'Telefone': telefone,
      'Email': email,
      'Endereco': endereco,
      'Cargo': cargo,
    };
  }
}
