import '../../core/database_helper.dart';
import '../models/usuarios_model.dart';

class UsuarioRepository {
  static Future<int> insert(Usuario usuario) async {
    final db = await DatabaseHelper.initDb();
    return await db.insert('Usuarios', usuario.toMap());
  }

  static Future<Usuario?> getUsuarioById(int id) async {
    final db = await DatabaseHelper.initDb();
    List<Map<String, dynamic>> maps = await db.query(
      'Usuarios',
      where: 'idUsuarios = ?',
      whereArgs: [id],
    );
    if (maps.isNotEmpty) {
      return Usuario.fromMap(maps.first);
    } else {
      return null;
    }
  }

  static Future<List<Usuario>> getAllUsuarios() async {
    final db = await DatabaseHelper.initDb();
    List<Map<String, dynamic>> maps = await db.query('Usuarios');
    return List.generate(maps.length, (i) => Usuario.fromMap(maps[i]));
  }

  static Future<int> update(Usuario usuario) async {
    final db = await DatabaseHelper.initDb();
    return await db.update(
      'Usuarios',
      usuario.toMap(),
      where: 'idUsuarios = ?',
      whereArgs: [usuario.idUsuario],
    );
  }

  static Future<int> delete(int id) async {
    final db = await DatabaseHelper.initDb();
    return await db.delete(
      'Usuarios',
      where: 'idUsuarios = ?',
      whereArgs: [id],
    );
  }
}
