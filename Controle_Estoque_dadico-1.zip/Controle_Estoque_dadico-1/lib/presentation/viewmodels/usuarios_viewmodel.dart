import 'package:flutter/material.dart';
import '../../data/models/usuarios_model.dart';
import '../../data/repositories/usuarios_repository.dart';

class UsuarioViewModel with ChangeNotifier {
  List<Usuario> _usuarios = [];
  bool _isLoading = false;

  List<Usuario> get usuarios => _usuarios;
  bool get isLoading => _isLoading;

  Future<void> fetchUsuarios() async {
    _isLoading = true;
    notifyListeners();

    try {
      _usuarios = await UsuarioRepository.getAllUsuarios();
    } catch (e) {
      debugPrint('Error fetching usuarios: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addUsuario(Usuario usuario) async {
    try {
      await UsuarioRepository.insert(usuario);
      _usuarios.add(usuario);
      notifyListeners();
    } catch (e) {
      debugPrint('Error adding usuario: $e');
    }
  }

  Future<void> updateUsuario(Usuario usuario) async {
    try {
      await UsuarioRepository.update(usuario);
      int index = _usuarios.indexWhere((u) => u.idUsuario == usuario.idUsuario);
      if (index != -1) {
        _usuarios[index] = usuario;
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Error updating usuario: $e');
    }
  }

  Future<void> deleteUsuario(int id) async {
    try {
      await UsuarioRepository.delete(id);
      _usuarios.removeWhere((u) => u.idUsuario == id);
      notifyListeners();
    } catch (e) {
      debugPrint('Error deleting usuario: $e');
    }
  }
}
