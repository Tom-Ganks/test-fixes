package com.example.controle_estoque_dadico

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
